# install k8s cluster
**First install docker** `sudo ./docker_install.sh`
1. change hostname `master` or `worker` 
"""
sudo vi /etc/hostname
"""
2. `./prepare.sh`
3. `./admin.sh`
4. sudo `./images.sh`

## Maseter node(only master node)
**You must update `--apiserver-advertise-address=192.168.10.210 ` in master.sh**
1. `./master.sh`
2. update `flannel.yaml` `-pod-network-cidr`(same as sudo kubeadm init --pod-network-cidr=10.10.0.0/16)
3. `kubectl apply -f kube-flannel.yml`

## Worker node(only worker node)
1. `kubeadm token create --print-join-command`
2. run 1 result 

